import pygame
import math
import random
import sys
import os
import wave
import struct
import time
import traceback

pygame.init()

# Инициализация звукового микшера
try:
    pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
    AUDIO_OK = True
except Exception:
    AUDIO_OK = False

# Инициализация экрана под телефон
screen = pygame.display.set_mode((0, 0))
REAL_W, REAL_H = screen.get_size()
PORTRAIT_MODE = REAL_W < REAL_H

VW, VH = 1280, 720
canvas = pygame.Surface((VW, VH))
clock = pygame.time.Clock()

font_sm = pygame.font.Font(None, 24)
font_md = pygame.font.Font(None, 32)
font_lg = pygame.font.Font(None, 48)

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BTN_CYAN = (0, 210, 255)
BTN_GREEN = (50, 240, 100)
BTN_RED = (255, 70, 70)
BTN_YELLOW = (255, 210, 0)

# ДЛИННАЯ КАРТА (35 000 КМ)
TOTAL_GOAL_DISTANCE = 35000.0
STAGE_CORONA = 6000.0
STAGE_VENUS = 12000.0
STAGE_BELT = 18000.0
STAGE_DEBRIS = 24000.0
STAGE_APPROACH = 29500.0

# Границы экрана
BOUND_TOP = 28.0
BOUND_BOTTOM = VH - 28.0

# Кэш готового текста (избавляет от тяжелых аллокаций шрифтов каждый кадр)
_TEXT_CACHE = {}


def get_cached_text(font_obj, text, color):
    key = (id(font_obj), text, color)
    if key not in _TEXT_CACHE:
        _TEXT_CACHE[key] = font_obj.render(text, True, color)
    return _TEXT_CACHE[key]


def map_touch_to_virtual(norm_x, norm_y):
    if PORTRAIT_MODE:
        vx = int((1.0 - norm_y) * VW)
        vy = int(norm_x * VH)
    else:
        vx = int(norm_x * VW)
        vy = int(norm_y * VH)
    return max(0, min(VW, vx)), max(0, min(VH, vy))


# =====================================================================
# === [ЗАЩИЩЕННАЯ СИСТЕМА ЗВУКОВ И ГОЛОСОВЫХ РЕПЛИК] ==================
# =====================================================================
def get_solarballs_dir():
    p = os.path.dirname(os.path.abspath(__file__))
    try:
        if any(f.lower().startswith("venus") for f in os.listdir(p)):
            return p
    except Exception:
        pass
    candidates = [
        "/storage/emulated/0/solarballs",
        "/sdcard/solarballs",
        "/storage/emulated/0/Download/solarballs",
        "/storage/emulated/0/Pictures/solarballs"
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    try:
        base_storage = "/storage/emulated/0"
        if os.path.exists(base_storage):
            for entry in os.scandir(base_storage):
                if entry.is_dir() and entry.name.lower() == "solarballs":
                    return entry.path
    except Exception:
        pass
    return p


class SoundEngine:
    def __init__(self):
        self.sounds = {}
        self.base_dir = get_solarballs_dir()
        self.sound_dir = os.path.join(self.base_dir, "sounds")

        self.aliases = {
            "flare": ["flare", "fire", "solar_flare"],
            "flare_warn": ["flare_warn", "firewarn", "fire_warn", "warn"],
            "grab": ["grab"],
            "throw": ["throw"],
            "push": ["push"],
            "dash": ["dash"],
            "hit": ["hit"],
            "damage": ["damage"],
            "debris_hit": ["debris_hit", "debris"],
            "bounce": ["bounce"],
            "venus_push": ["venus_push"],
            "venus_roar": ["venus_roar", "roar"],
            "blip": ["blip"],
            "win": ["win"],
            "voice_mercury": ["voice_mercury", "mercury_voice", "mercury_intro", "голос_меркурий"],
            "voice_venus": ["voice_venus", "venus_voice", "venus_intro", "голос_венера"],
            "voice_sun": ["voice_sun", "sun_voice", "sun_intro", "голос_солнце"]
        }

    def find_sound_file(self, key):
        if not os.path.exists(self.sound_dir):
            return None
        candidates = self.aliases.get(key, [key])
        valid_exts = [".wav", ".mp3", ".ogg"]
        try:
            for f in os.listdir(self.sound_dir):
                base, ext = os.path.splitext(f)
                if base.lower() in candidates and ext.lower() in valid_exts:
                    return os.path.join(self.sound_dir, f)
        except Exception:
            pass
        return None

    def check_sounds_exist(self):
        if not os.path.exists(self.sound_dir):
            return False
        base_keys = ["grab", "throw", "push", "dash", "hit", "flare_warn", "flare", "damage"]
        for k in base_keys:
            if not self.find_sound_file(k):
                return False
        return True

    def build_wav(self, key, default_filename, duration, func):
        if self.find_sound_file(key) is not None:
            return

        filepath = os.path.join(self.sound_dir, default_filename)
        rate = 22050
        n_samples = int(rate * duration)
        raw = bytearray()
        for i in range(n_samples):
            t = i / rate
            val = max(-1.0, min(1.0, func(t, duration)))
            ival = int(val * 32767)
            raw.extend(struct.pack("<h", ival))

        with wave.open(filepath, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(rate)
            w.writeframes(raw)

    def generate_missing_sounds(self, progress_callback):
        os.makedirs(self.sound_dir, exist_ok=True)
        sfx_keys = [
            "grab", "throw", "push", "dash", "hit",
            "flare_warn", "flare", "damage", "debris_hit",
            "bounce", "venus_push", "venus_roar", "blip", "win"
        ]
        total = len(sfx_keys)

        generators = {
            "grab": ("grab.wav", 0.35, lambda t, d: math.sin(2 * math.pi * (160 + (t / d) * 450) * t) * (1.0 - t / d)),
            "throw": ("throw.wav", 0.4, lambda t, d: math.sin(2 * math.pi * (820 - (t / d) * 550) * t) * (1.0 - t / d)),
            "push": ("push.wav", 0.4, lambda t, d: math.sin(2 * math.pi * 95 * t) * math.exp(-t * 6.0) * 0.7 + random.uniform(-0.6, 0.6) * (1.0 - t / d) * 0.3),
            "dash": ("dash.wav", 0.28, lambda t, d: (math.sin(2 * math.pi * (650 - (t / d) * 420) * t) * 0.5 + random.uniform(-0.5, 0.5) * 0.5) * (1.0 - t / d)),
            "hit": ("hit.wav", 0.55, lambda t, d: (math.sin(2 * math.pi * 75 * t) * 0.7 + random.uniform(-1, 1) * 0.4) * math.exp(-t * 8.0)),
            "flare_warn": ("flare_warn.wav", 1.2, lambda t, d: math.sin(2 * math.pi * (540 + 220 * math.sin(2 * math.pi * 7.5 * t)) * t) * (0.75 + 0.25 * math.sin(2 * math.pi * 15 * t)) * 0.8),
            "flare": ("flare.wav", 0.85, lambda t, d: (math.sin(2 * math.pi * 65 * t) + random.uniform(-0.4, 0.4)) * math.sin((t / d) * math.pi)),
            "damage": ("damage.wav", 0.35, lambda t, d: (math.sin(2 * math.pi * 280 * t) + random.uniform(-0.5, 0.5)) * math.exp(-t * 9.0)),
            "debris_hit": ("debris_hit.wav", 0.45, lambda t, d: (math.sin(2 * math.pi * 880 * t) * 0.6 + math.sin(2 * math.pi * 1320 * t) * 0.4) * math.exp(-t * 9.0)),
            "bounce": ("bounce.wav", 0.18, lambda t, d: math.sin(2 * math.pi * (140 - t * 350) * t) * math.exp(-t * 14.0)),
            "venus_push": ("venus_push.wav", 0.45, lambda t, d: math.sin(2 * math.pi * 65 * t) * 0.8 + random.uniform(-0.4, 0.4) * 0.4),
            "venus_roar": ("venus_roar.wav", 0.65, lambda t, d: (math.sin(2 * math.pi * (110 + 35 * math.sin(2 * math.pi * 20 * t)) * t) * 0.6 + random.uniform(-0.4, 0.4) * 0.5) * (1.0 - (t / d) ** 2)),
            "blip": ("blip.wav", 0.08, lambda t, d: math.sin(2 * math.pi * 840 * t) * math.exp(-t * 35.0)),
            "win": ("win.wav", 1.4, lambda t, d: (math.sin(2 * math.pi * 261.6 * t) + math.sin(2 * math.pi * 329.6 * t) + math.sin(2 * math.pi * 392.0 * t)) * 0.3 * math.sin((t / d) * math.pi))
        }

        for idx, key in enumerate(sfx_keys):
            progress_callback((idx + 1) / total, f"Проверка звука: {key}...")
            fname, dur, f_func = generators[key]
            self.build_wav(key, fname, dur, f_func)

    def load_sounds(self):
        if not AUDIO_OK:
            return
        for k in self.aliases:
            p = self.find_sound_file(k)
            if p:
                try:
                    snd = pygame.mixer.Sound(p)
                    if k.startswith("voice_"):
                        snd.set_volume(1.0)
                    else:
                        snd.set_volume(0.85)
                    self.sounds[k] = snd
                except Exception:
                    pass

    def get_duration(self, key, default=4.0):
        if AUDIO_OK and key in self.sounds:
            try:
                length = self.sounds[key].get_length()
                if length > 0.5:
                    return length
            except Exception:
                pass
        return default

    def play(self, name):
        if AUDIO_OK and name in self.sounds:
            try:
                self.sounds[name].play()
            except Exception:
                pass

    def stop_all(self):
        if AUDIO_OK:
            try:
                pygame.mixer.stop()
            except Exception:
                pass


SOUNDS = SoundEngine()


# =====================================================================
# === [ТЕКСТУРЫ И КЭШИРОВАНИЕ] =========================================
# =====================================================================
class TextureManager:
    def __init__(self):
        self.base_dir = get_solarballs_dir()
        self.textures = {}
        self.scaled_cache = {}
        self.load_all()

    def load_img(self, name):
        if not os.path.exists(self.base_dir):
            return None
        target_file = None
        try:
            for f in os.listdir(self.base_dir):
                base, ext = os.path.splitext(f)
                if base.lower() == name.lower() and ext.lower() in [".jpg", ".png", ".jpeg", ".webp"]:
                    target_file = f
                    break
        except Exception:
            return None

        if not target_file:
            return None

        full_path = os.path.join(self.base_dir, target_file)
        try:
            if name == "bg":
                return pygame.image.load(full_path).convert()
            if name == "flare":
                return pygame.image.load(full_path).convert()

            if name == "sun":
                raw = pygame.image.load(full_path).convert_alpha()
                w, h = raw.get_size()
                mask = pygame.mask.from_threshold(raw, (0, 0, 0, 255), (60, 60, 60, 255))
                mask.invert()
                mask_surf = mask.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
                cut = pygame.Surface((w, h), pygame.SRCALPHA)
                cut.blit(raw, (0, 0))
                cut.blit(mask_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
                circle_mask = pygame.Surface((w, h), pygame.SRCALPHA)
                pygame.draw.circle(circle_mask, (255, 255, 255, 255), (w // 2, h // 2), min(w, h) // 2)
                cut.blit(circle_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
                return cut

            if name == "asteroid":
                raw = pygame.image.load(full_path).convert_alpha()
                w, h = raw.get_size()
                mask = pygame.mask.from_threshold(raw, (0, 0, 0, 255), (32, 32, 32, 255))
                mask.invert()
                mask_surf = mask.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0))
                cut = pygame.Surface((w, h), pygame.SRCALPHA)
                cut.blit(raw, (0, 0))
                cut.blit(mask_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
                return cut

            raw = pygame.image.load(full_path).convert_alpha()
            w, h = raw.get_size()
            circle_mask = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.circle(circle_mask, (255, 255, 255, 255), (w // 2, h // 2), min(w, h) // 2)
            masked = pygame.Surface((w, h), pygame.SRCALPHA)
            masked.blit(raw, (0, 0))
            masked.blit(circle_mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            return masked
        except Exception:
            return None

    def load_all(self):
        for key in ["mercury", "venus", "asteroid", "sun", "earth", "mars", "bg", "flare"]:
            self.textures[key] = self.load_img(key)

    def get(self, key):
        return self.textures.get(key, None)

    def get_scaled(self, key, size):
        tex = self.get(key)
        if tex is None:
            return None
        w, h = int(size[0]), int(size[1])
        cache_key = (key, w, h)
        if cache_key not in self.scaled_cache:
            self.scaled_cache[cache_key] = pygame.transform.smoothscale(tex, (w, h))
        return self.scaled_cache[cache_key]


TM = TextureManager()


# =====================================================================
# === [КАМЕРА] =========================================================
# =====================================================================
class LinearCamera:
    def __init__(self):
        self.x = 0.0
        self.y = VH / 2
        self.shake = 0.0

    def update(self, dt, target_x, target_y):
        self.x += (target_x - (self.x + VW * 0.42)) * 6.0 * dt
        desired_cam_y = max(VH * 0.46, min(VH * 0.54, target_y))
        self.y += (desired_cam_y - self.y) * 4.0 * dt
        if self.shake > 0:
            self.shake = max(0.0, self.shake - dt * 18.0)

    def project(self, wx, wy):
        sx = wx - self.x
        sy = wy - self.y + VH / 2
        if self.shake > 0:
            sx += random.uniform(-self.shake, self.shake)
            sy += random.uniform(-self.shake, self.shake)
        return int(sx), int(sy)


# =====================================================================
# === [РЕНДЕР ПЛАНЕТ: СТИЛЬ SOLARBALLS] ===============================
# =====================================================================
class PlanetRenderer:
    @staticmethod
    def draw_body(surf, sx, sy, r, rot_x, rot_y, tex_key, emotion="NORMAL", look_dx=1.0, look_dy=0.0, talk_mouth=0.0):
        if sx < -r - 60 or sx > VW + r + 60 or sy < -r - 60 or sy > VH + r + 60:
            return sx, sy, r

        tex_scaled = TM.get_scaled(tex_key, (r * 2, r * 2))
        if tex_scaled is not None:
            surf.blit(tex_scaled, (sx - r, sy - r))
        else:
            pygame.draw.circle(surf, WHITE, (sx, sy), r, 2)
            w_ratio = math.sin(rot_x)
            rw = int(abs(w_ratio) * r)
            if rw > 2:
                pygame.draw.ellipse(surf, WHITE, pygame.Rect(sx - rw, sy - r, rw * 2, r * 2), 1)
            eh = int(abs(math.sin(rot_y)) * r * 0.7)
            if eh > 2:
                pygame.draw.ellipse(surf, WHITE, pygame.Rect(sx - r, sy - eh, r * 2, eh * 2), 1)

        ld = max(0.001, math.hypot(look_dx, look_dy))
        fx = int((look_dx / ld) * r * 0.28)
        fy = int((look_dy / ld) * r * 0.2)

        eye_sep = max(4, int(r * 0.32))
        eye_y = sy + fy - int(r * 0.1)
        lx = sx + fx - eye_sep
        rx = sx + fx + eye_sep
        er = max(4, int(r * 0.17))

        if emotion == "PANIC":
            per = int(er * 1.35)
            pygame.draw.circle(surf, WHITE, (lx, eye_y), per)
            pygame.draw.circle(surf, BLACK, (lx, eye_y), per, 2)
            pygame.draw.circle(surf, WHITE, (rx, eye_y), per)
            pygame.draw.circle(surf, BLACK, (rx, eye_y), per, 2)
            m_h = int(r * (0.2 + talk_mouth * 0.35))
            pygame.draw.ellipse(surf, BLACK, (sx + fx - int(er * 0.9), sy + fy + int(r * 0.1), int(er * 1.8), m_h))

        elif emotion == "STUNNED":
            for ex in (lx, rx):
                pygame.draw.line(surf, BLACK, (ex - er, eye_y - er), (ex + er, eye_y + er), 3)
                pygame.draw.line(surf, BLACK, (ex - er, eye_y + er), (ex + er, eye_y - er), 3)
            pygame.draw.circle(surf, BLACK, (sx + fx, sy + fy + int(r * 0.2)), er)

        elif emotion == "ANGRY":
            pygame.draw.circle(surf, WHITE, (lx, eye_y), er)
            pygame.draw.circle(surf, BLACK, (lx, eye_y), er, 2)
            pygame.draw.circle(surf, WHITE, (rx, eye_y), er)
            pygame.draw.circle(surf, BLACK, (rx, eye_y), er, 2)
            pygame.draw.line(surf, BLACK, (lx - er - 2, eye_y - er - 4), (lx + er + 2, eye_y - 2), 3)
            pygame.draw.line(surf, BLACK, (rx + er + 2, eye_y - er - 4), (rx - er - 2, eye_y - 2), 3)
            m_h = int(r * (0.22 + talk_mouth * 0.28))
            m_rect = pygame.Rect(sx + fx - eye_sep, sy + fy + int(r * 0.12), eye_sep * 2, m_h)
            pygame.draw.rect(surf, BLACK, m_rect)
            pygame.draw.line(surf, WHITE, (m_rect.left, m_rect.centery), (m_rect.right, m_rect.centery), 1)

        elif emotion == "SMIRK":
            pygame.draw.circle(surf, WHITE, (lx, eye_y), er)
            pygame.draw.circle(surf, BLACK, (lx, eye_y), er, 2)
            pygame.draw.circle(surf, WHITE, (rx, eye_y), er)
            pygame.draw.circle(surf, BLACK, (rx, eye_y), er, 2)
            pygame.draw.line(surf, BLACK, (lx - er - 2, eye_y - er - 2), (lx + er, eye_y - er), 2)
            pygame.draw.line(surf, BLACK, (rx - er, eye_y - er), (rx + er + 2, eye_y - er - 3), 2)
            m_h = int(r * (0.2 + talk_mouth * 0.25))
            pygame.draw.arc(surf, BLACK, (sx + fx - eye_sep, sy + fy + 2, eye_sep * 2, m_h), 3.4, 6.0, 3)

        elif emotion == "HAPPY":
            pygame.draw.circle(surf, WHITE, (lx, eye_y), er)
            pygame.draw.circle(surf, BLACK, (lx, eye_y), er, 2)
            pygame.draw.circle(surf, WHITE, (rx, eye_y), er)
            pygame.draw.circle(surf, BLACK, (rx, eye_y), er, 2)
            m_h = int(r * (0.2 + talk_mouth * 0.25))
            pygame.draw.arc(surf, BLACK, (sx + fx - eye_sep, sy + fy + 2, eye_sep * 2, m_h), 3.2, 6.2, 3)

        else:
            pygame.draw.circle(surf, WHITE, (lx, eye_y), er)
            pygame.draw.circle(surf, BLACK, (lx, eye_y), er, 2)
            pygame.draw.circle(surf, WHITE, (rx, eye_y), er)
            pygame.draw.circle(surf, BLACK, (rx, eye_y), er, 2)
            m_h = int(r * (0.15 + talk_mouth * 0.25))
            pygame.draw.line(surf, BLACK, (sx + fx - int(r * 0.2), sy + fy + int(r * 0.22)),
                             (sx + fx + int(r * 0.2), sy + fy + int(r * 0.22)), 3)

        return sx, sy, r

    @staticmethod
    def draw_sun(surf, sx, sy, r, pulse, talk_mouth=0.0):
        tex_scaled = TM.get_scaled("sun", (r * 2, r * 2))
        if tex_scaled is not None:
            surf.blit(tex_scaled, (sx - r, sy - r))
        else:
            pygame.draw.circle(surf, WHITE, (sx, sy), r, 3)
            num_rays = 28
            for i in range(num_rays):
                a = (i / num_rays) * math.pi * 2
                ray_len = 16 + math.sin(pulse + i) * 12
                x1 = sx + math.cos(a) * (r + 4)
                y1 = sy + math.sin(a) * (r + 4)
                x2 = sx + math.cos(a) * (r + 4 + ray_len)
                y2 = sy + math.sin(a) * (r + 4 + ray_len)
                pygame.draw.line(surf, WHITE, (int(x1), int(y1)), (int(x2), int(y2)), 2)

        eye_y = sy - 40
        pygame.draw.circle(surf, WHITE, (sx + 80, eye_y), 24)
        pygame.draw.circle(surf, BLACK, (sx + 80, eye_y), 24, 3)
        pygame.draw.circle(surf, WHITE, (sx + 150, eye_y), 24)
        pygame.draw.circle(surf, BLACK, (sx + 150, eye_y), 24, 3)
        m_h = int(35 + talk_mouth * 35)
        pygame.draw.arc(surf, BLACK, (sx + 75, sy + 25, 90, m_h), 3.3, 6.1, 4)


# =====================================================================
# === [СПОСОБНОСТИ МЕРКУРИЯ (ИСПРАВЛЕННЫЙ ПРИЦЕЛ)] =====================
# =====================================================================
class MercuryAbilities:
    def __init__(self, owner):
        self.owner = owner
        self.grav_radius = 210.0
        self.grav_cd = 0.0
        self.dash_cd = 0.0
        self.repulse_cd = 0.0
        self.repulse_anim = 0.0

        self.grav_anim_timer = 0.0
        self.orbit_ast = None
        self.orbit_dist = 68.0
        self.aim_angle = math.pi  # По умолчанию смотрим влево (в сторону преследующей Венеры)

    def update(self, dt, ui, obstacles, venus_target=None):
        if self.grav_cd > 0:
            self.grav_cd -= dt
        if self.dash_cd > 0:
            self.dash_cd -= dt
        if self.repulse_cd > 0:
            self.repulse_cd -= dt
        if self.repulse_anim > 0:
            self.repulse_anim -= dt

        if ui.dash_pressed and self.dash_cd <= 0:
            self.dash_cd = 2.4
            self.owner.invuln = 0.4
            SOUNDS.play("dash")
            ang = math.atan2(ui.dy, ui.dx) if (abs(ui.dx) > 0.05 or abs(ui.dy) > 0.05) else 0.0
            self.owner.vx += math.cos(ang) * 750.0
            self.owner.vy += math.sin(ang) * 750.0

        if ui.repulse_pressed and self.repulse_cd <= 0:
            self.repulse_cd = 2.8
            self.repulse_anim = 0.4
            SOUNDS.play("push")
            for obj in obstacles:
                d = math.hypot(self.owner.x - obj.x, self.owner.y - obj.y)
                if d < 300.0:
                    push_spd = max(600.0, 1050.0 * (1.0 - d / 300.0))
                    nx = (obj.x - self.owner.x) / max(1.0, d)
                    ny = (obj.y - self.owner.y) / max(1.0, d)
                    obj.vx = nx * push_spd + self.owner.vx * 0.3
                    obj.vy = ny * push_spd + self.owner.vy * 0.3
                    obj.owner = "player"
                    obj.owner_timer = 1.5
                    obj.slung_by_player = True
                    obj.held_by_venus = False
                    obj.captured = False

        # ИСПРАВЛЕНИЕ ПРИЦЕЛА:
        # Угол перезаписывается только тогда, когда игрок САМ отклоняет джойстик!
        # Никакого сброса по направлению скорости: угол жестко запоминается!
        if abs(ui.dx) > 0.15 or abs(ui.dy) > 0.15:
            self.aim_angle = math.atan2(ui.dy, ui.dx)

        if ui.grav_held and self.grav_cd <= 0:
            self.grav_anim_timer += dt * 3.5
            for obj in obstacles:
                if obj is self.orbit_ast or getattr(obj, "held_by_venus", False):
                    continue
                if abs(obj.x - self.owner.x) < self.grav_radius and abs(obj.y - self.owner.y) < self.grav_radius:
                    dist = math.hypot(self.owner.x - obj.x, self.owner.y - obj.y)
                    if 5 < dist < self.grav_radius:
                        pull = min(1700.0, 8500000.0 / (dist * dist))
                        obj.vx += ((self.owner.x - obj.x) / dist) * pull * dt
                        obj.vy += ((self.owner.y - obj.y) / dist) * pull * dt
                        if self.orbit_ast is None and dist < 120:
                            self.orbit_ast = obj
                            self.orbit_ast.captured = True
                            SOUNDS.play("grab")
                            # Если стик джойстика сейчас не трогают — автоматически наводим на Венеру
                            if abs(ui.dx) <= 0.15 and abs(ui.dy) <= 0.15 and venus_target:
                                self.aim_angle = math.atan2(venus_target.y - self.owner.y, venus_target.x - self.owner.x)

            if self.orbit_ast and self.orbit_ast in obstacles:
                hold_ang = self.aim_angle + math.pi
                tx = self.owner.x + math.cos(hold_ang) * self.orbit_dist
                ty = self.owner.y + math.sin(hold_ang) * self.orbit_dist
                self.orbit_ast.x += (tx - self.orbit_ast.x) * 16.0 * dt
                self.orbit_ast.y += (ty - self.orbit_ast.y) * 16.0 * dt
                self.orbit_ast.vx = 0.0
                self.orbit_ast.vy = 0.0
            else:
                self.orbit_ast = None
        elif ui.grav_released:
            self.release_shot()
        else:
            self.grav_anim_timer = 0.0

    def release_shot(self):
        self.grav_cd = 0.8
        if self.orbit_ast:
            obj = self.orbit_ast
            obj.captured = False
            obj.slung_by_player = True
            obj.owner = "player"
            obj.owner_timer = 1.5
            launch_speed = 1150.0
            obj.vx = math.cos(self.aim_angle) * launch_speed
            obj.vy = math.sin(self.aim_angle) * launch_speed
            self.owner.vx -= math.cos(self.aim_angle) * 450.0
            self.owner.vy -= math.sin(self.aim_angle) * 450.0
            self.owner.invuln = 0.35
            self.orbit_ast = None
            SOUNDS.play("throw")

    def draw(self, surf, cam, ui):
        sx, sy = cam.project(self.owner.x, self.owner.y)

        if self.repulse_anim > 0:
            r_ring = int((1.0 - self.repulse_anim / 0.4) * 300.0)
            pygame.draw.circle(surf, BTN_CYAN, (sx, sy), r_ring, 3)

        if ui.grav_held and self.grav_cd <= 0:
            for ring_i in range(2):
                p = (self.grav_anim_timer + ring_i * 0.5) % 1.0
                curr_r = int(self.owner.r + (self.grav_radius - self.owner.r) * (1.0 - p))
                pygame.draw.circle(surf, WHITE, (sx, sy), curr_r, 1)

            arrow_len = 220
            ex = sx + int(math.cos(self.aim_angle) * arrow_len)
            ey = sy + int(math.sin(self.aim_angle) * arrow_len)
            pygame.draw.line(surf, WHITE, (sx, sy), (ex, ey), 2)
            pygame.draw.circle(surf, WHITE, (ex, ey), 5, 2)

            if self.orbit_ast:
                ax, ay = cam.project(self.orbit_ast.x, self.orbit_ast.y)
                pygame.draw.line(surf, WHITE, (sx, sy), (ax, ay), 2)


# =====================================================================
# === [АТАКИ ВЕНЕРЫ] ===================================================
# =====================================================================
class VenusCombatSystem:
    def __init__(self, owner):
        self.owner = owner
        self.held_asteroids = []
        self.grab_timer = 1.1
        self.grav_anim = 0.0
        self.attack_mode = "PINCER"
        self.repulse_cd = 2.0
        self.repulse_anim = 0.0

    def reset(self):
        for ast in self.held_asteroids:
            ast.held_by_venus = False
        self.held_asteroids.clear()

    def update(self, dt, mercury, obstacles, in_belt):
        max_held = 3 if in_belt else (2 if self.attack_mode == "PINCER" else 1)
        self.grav_anim += dt * 3.5
        self.grab_timer -= dt

        if self.repulse_cd > 0:
            self.repulse_cd -= dt
        if self.repulse_anim > 0:
            self.repulse_anim -= dt

        if self.repulse_cd <= 0 and self.owner.stun_timer <= 0:
            should_repulse = False
            if math.hypot(self.owner.x - mercury.x, self.owner.y - mercury.y) < 280.0:
                should_repulse = True
            else:
                nearby = sum(1 for obj in obstacles if math.hypot(self.owner.x - obj.x, self.owner.y - obj.y) < 220.0)
                if nearby >= 2:
                    should_repulse = True

            if should_repulse:
                self.repulse_cd = random.uniform(1.6, 2.2)
                self.repulse_anim = 0.35
                SOUNDS.play("venus_push")
                for obj in obstacles:
                    d = math.hypot(self.owner.x - obj.x, self.owner.y - obj.y)
                    if d < 280.0 and not obj.captured and obj not in self.held_asteroids:
                        push_spd = max(550.0, 920.0 * (1.0 - d / 280.0))
                        nx = (obj.x - self.owner.x) / max(1.0, d)
                        ny = (obj.y - self.owner.y) / max(1.0, d)
                        obj.vx = nx * push_spd
                        obj.vy = ny * push_spd
                        obj.owner = "venus"
                        obj.owner_timer = 1.8
                        obj.slung_by_player = False
                        obj.held_by_venus = False

        if len(self.held_asteroids) < max_held:
            for obj in obstacles:
                if obj.captured or getattr(obj, "held_by_venus", False) or getattr(obj, "slung_by_player", False):
                    continue
                if abs(obj.x - self.owner.x) < 420 and abs(obj.y - self.owner.y) < 420:
                    d = math.hypot(self.owner.x - obj.x, self.owner.y - obj.y)
                    if d < 420:
                        obj.vx += ((self.owner.x - obj.x) / d) * 750.0 * dt
                        obj.vy += ((self.owner.y - obj.y) / d) * 750.0 * dt
                        if d < 80:
                            obj.held_by_venus = True
                            obj.owner = "venus"
                            self.held_asteroids.append(obj)
                            if len(self.held_asteroids) >= max_held:
                                self.grab_timer = 1.1 if in_belt else 1.4
                                break

        for i, ast in enumerate(self.held_asteroids):
            ang = self.grav_anim + (i * (math.pi * 2 / max(1, len(self.held_asteroids))))
            ast.x = self.owner.x + math.cos(ang) * (self.owner.r + 32)
            ast.y = self.owner.y + math.sin(ang) * (self.owner.r + 32)

        if len(self.held_asteroids) > 0 and self.grab_timer <= 0:
            SOUNDS.play("throw")
            if self.attack_mode == "PINCER" and len(self.held_asteroids) >= 2:
                angles = [-0.34, 0.34]
                for idx, ast in enumerate(self.held_asteroids[:2]):
                    ast.held_by_venus = False
                    ast.owner = "venus"
                    ast.owner_timer = 2.0
                    base_ang = math.atan2(mercury.y - ast.y, (mercury.x + 90.0) - ast.x)
                    fire_ang = base_ang + angles[idx % 2]
                    spd = random.uniform(620.0, 740.0)
                    ast.vx = math.cos(fire_ang) * spd
                    ast.vy = math.sin(fire_ang) * spd
                self.attack_mode = "DIRECT"
            else:
                for ast in self.held_asteroids:
                    ast.held_by_venus = False
                    ast.owner = "venus"
                    ast.owner_timer = 2.0
                    intercept_x = mercury.x + mercury.vx * 0.5 + 90.0
                    intercept_y = mercury.y + mercury.vy * 0.5
                    ang = math.atan2(intercept_y - ast.y, intercept_x - ast.x)
                    spd = random.uniform(590.0, 720.0)
                    ast.vx = math.cos(ang) * spd
                    ast.vy = math.sin(ang) * spd
                self.attack_mode = "PINCER"

            self.held_asteroids.clear()
            self.grab_timer = random.uniform(1.4, 2.0) if not in_belt else random.uniform(1.0, 1.5)

    def draw(self, surf, cam):
        sx, sy = cam.project(self.owner.x, self.owner.y)
        if self.repulse_anim > 0:
            r_ring = int((1.0 - self.repulse_anim / 0.35) * 280.0)
            pygame.draw.circle(surf, (255, 100, 50), (sx, sy), r_ring, 3)

        for ast in self.held_asteroids:
            ax, ay = cam.project(ast.x, ast.y)
            pygame.draw.line(surf, WHITE, (sx, sy), (ax, ay), 1)


# =====================================================================
# === [СУЩНОСТИ, ДВИЖУЩИЕСЯ АСТЕРОИДЫ И МУСОР] ========================
# =====================================================================
class Mercury:
    def __init__(self):
        self.x = 450.0
        self.y = 360.0
        self.vx = 0.0
        self.vy = 0.0
        self.r = 26
        self.hp = 100
        self.rot_x = 0.0
        self.rot_y = 0.3
        self.emotion = "NORMAL"
        self.invuln = 0.0
        self.abilities = MercuryAbilities(self)

    def update(self, dt, ui, obstacles, venus_target=None):
        if self.invuln > 0:
            self.invuln -= dt

        self.rot_x += (self.vx * 0.007) * dt
        self.rot_y += (self.vy * 0.007) * dt
        self.abilities.update(dt, ui, obstacles, venus_target)

        accel = 1350.0
        self.vx += ui.dx * accel * dt
        self.vy += ui.dy * accel * dt
        self.vx *= 0.915
        self.vy *= 0.915

        self.x += self.vx * dt
        self.y += self.vy * dt

        if self.y < BOUND_TOP:
            self.y = BOUND_TOP
            if abs(self.vy) > 80:
                SOUNDS.play("bounce")
            self.vy = abs(self.vy) * 0.4
        elif self.y > BOUND_BOTTOM:
            self.y = BOUND_BOTTOM
            if abs(self.vy) > 80:
                SOUNDS.play("bounce")
            self.vy = -abs(self.vy) * 0.4

    def draw(self, surf, cam, ui):
        self.abilities.draw(surf, cam, ui)
        sx, sy = cam.project(self.x, self.y)
        return PlanetRenderer.draw_body(
            surf, sx, sy, self.r, self.rot_x, self.rot_y, "mercury", self.emotion,
            math.cos(self.abilities.aim_angle), math.sin(self.abilities.aim_angle)
        )


class VenusChaserAI:
    def __init__(self):
        self.x = 80.0
        self.y = 360.0
        self.vx = 0.0
        self.vy = 0.0
        self.r = 52
        self.hp = 100
        self.rot_x = 0.0
        self.rot_y = 0.4
        self.emotion = "ANGRY"
        self.stun_timer = 0.0
        self.is_enraged = False
        self.combat = VenusCombatSystem(self)

    def update(self, dt, mercury, obstacles):
        self.rot_x += 1.4 * dt

        if self.stun_timer > 0:
            self.stun_timer -= dt
            self.emotion = "STUNNED"
            self.is_enraged = False
            self.combat.reset()
            self.vx *= 0.88
            self.vy *= 0.88
            self.x += self.vx * dt
            self.y += self.vy * dt
            return

        in_belt = STAGE_BELT <= mercury.x <= STAGE_DEBRIS
        dist_to_mercury = mercury.x - self.x

        if dist_to_mercury > 380.0:
            if not self.is_enraged:
                SOUNDS.play("venus_roar")
            self.is_enraged = True
            speed_mult = 5.0
            target_lead_x = mercury.x - 220.0
        else:
            self.is_enraged = False
            speed_mult = 3.6
            target_lead_x = mercury.x - 280.0

        self.emotion = "ANGRY"
        desired_y = mercury.y + math.sin(mercury.x * 0.008) * 85.0

        self.vx += (target_lead_x - self.x) * speed_mult * dt
        self.vy += (desired_y - self.y) * 4.0 * dt
        self.vx *= 0.91
        self.vy *= 0.91
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.y = max(BOUND_TOP, min(BOUND_BOTTOM, self.y))

        self.combat.update(dt, mercury, obstacles, in_belt)

    def draw(self, surf, cam, mercury):
        self.combat.draw(surf, cam)
        sx, sy = cam.project(self.x, self.y)
        return PlanetRenderer.draw_body(
            surf, sx, sy, self.r, self.rot_x, self.rot_y, "venus", self.emotion,
            mercury.x - self.x, mercury.y - self.y
        )


class TrackAsteroid:
    def __init__(self, x, y, r):
        self.x = float(x)
        self.y = float(y)
        self.r = r
        self.captured = False
        self.held_by_venus = False
        self.slung_by_player = False
        self.owner = "neutral"
        self.owner_timer = 0.0

        self.is_moving = random.random() < 0.35
        if self.is_moving:
            self.vx = random.uniform(-140.0, -40.0)
            self.vy = random.choice([-1, 1]) * random.uniform(60.0, 140.0)
        else:
            self.vx = random.uniform(-20.0, 20.0)
            self.vy = random.uniform(-20.0, 20.0)

        self.angle = random.uniform(0, 6.28)
        self.rot_speed = random.choice([-1, 1]) * random.uniform(1.2, 3.2)
        num = random.randint(6, 8)
        self.pts = []
        for i in range(num):
            a = (i / num) * math.pi * 2
            self.pts.append((a, self.r * random.uniform(0.75, 1.25)))

    def update(self, dt):
        self.angle += self.rot_speed * dt

        if self.owner_timer > 0:
            self.owner_timer -= dt
            if self.owner_timer <= 0:
                self.owner = "neutral"
                self.slung_by_player = False

        if not self.captured and not self.held_by_venus:
            self.x += self.vx * dt
            self.y += self.vy * dt

            if self.y < BOUND_TOP + 10:
                self.y = BOUND_TOP + 10
                self.vy = abs(self.vy)
            elif self.y > BOUND_BOTTOM - 10:
                self.y = BOUND_BOTTOM - 10
                self.vy = -abs(self.vy)

            if self.slung_by_player:
                self.vx *= 0.992
                self.vy *= 0.992

    def draw(self, surf, cam):
        sx, sy = cam.project(self.x, self.y)
        if sx < -self.r - 30 or sx > VW + self.r + 30:
            return

        tex_scaled = TM.get_scaled("asteroid", (self.r * 2, self.r * 2))
        if tex_scaled is not None:
            surf.blit(tex_scaled, (sx - self.r, sy - self.r))
        else:
            poly = []
            for a, rad in self.pts:
                px = sx + math.cos(a + self.angle) * rad
                py = sy + math.sin(a + self.angle) * rad
                poly.append((int(px), int(py)))
            pygame.draw.polygon(surf, WHITE, poly, 2)


class ForegroundAsteroid:
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.r = 110
        self.speed_x = random.uniform(-850.0, -620.0)

    def update(self, dt):
        self.x += self.speed_x * dt

    def draw(self, surf, cam):
        sx, sy = cam.project(self.x, self.y)
        if sx < -self.r * 2 or sx > VW + self.r * 2:
            return

        tex_scaled = TM.get_scaled("asteroid", (self.r * 2, self.r * 2))
        if tex_scaled is not None:
            surf.blit(tex_scaled, (sx - self.r, sy - self.r))
        else:
            pygame.draw.circle(surf, (20, 20, 25), (sx, sy), self.r)
            pygame.draw.circle(surf, WHITE, (sx, sy), self.r, 3)


class SpaceDebris:
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.r = 24
        self.vx = random.uniform(-35.0, -10.0)
        self.vy = random.uniform(-25.0, 25.0)
        self.captured = False
        self.held_by_venus = False
        self.slung_by_player = False
        self.owner = "neutral"
        self.owner_timer = 0.0

        self.angle = random.uniform(0, 6.28)
        self.rot_speed = random.uniform(-3.5, 3.5)

    def update(self, dt):
        self.angle += self.rot_speed * dt
        if self.owner_timer > 0:
            self.owner_timer -= dt
            if self.owner_timer <= 0:
                self.owner = "neutral"
                self.slung_by_player = False

        if not self.captured and not self.held_by_venus:
            self.x += self.vx * dt
            self.y += self.vy * dt

    def draw(self, surf, cam):
        sx, sy = cam.project(self.x, self.y)
        if sx < -50 or sx > VW + 50:
            return
        w_len = 22
        cos_a = math.cos(self.angle)
        sin_a = math.sin(self.angle)
        pygame.draw.circle(surf, WHITE, (sx, sy), 8, 2)
        pygame.draw.line(surf, WHITE, (sx, sy), (sx + int(cos_a * w_len), sy + int(sin_a * w_len)), 2)
        pygame.draw.circle(surf, WHITE, (sx + int(cos_a * w_len), sy + int(sin_a * w_len)), 3)
        p_cos = -sin_a
        p_sin = cos_a
        pygame.draw.line(surf, WHITE, (sx - int(p_cos * 20), sy - int(p_sin * 20)),
                         (sx + int(p_cos * 20), sy + int(p_sin * 20)), 2)


# СОЛНЕЧНАЯ ВСПЫШКА
class SolarFlare:
    def __init__(self, fixed_y):
        self.y = fixed_y
        self.h = 115
        self.warn_time = 1.8
        self.active_time = 0.65
        self.done = False
        self.fired_sound = False
        SOUNDS.play("flare_warn")

    def update(self, dt, cam):
        if self.warn_time > 0:
            self.warn_time -= dt
        elif self.active_time > 0:
            if not self.fired_sound:
                SOUNDS.play("flare")
                self.fired_sound = True
            self.active_time -= dt
            cam.shake = 3.5
        else:
            self.done = True

    def is_firing(self):
        return self.warn_time <= 0 and self.active_time > 0

    def draw(self, surf):
        top_y = int(self.y - self.h // 2)
        tex_scaled = TM.get_scaled("flare", (VW, self.h))
        if self.warn_time > 0:
            for x in range(0, VW, 45):
                pygame.draw.line(surf, WHITE, (x, top_y), (x + 25, top_y), 1)
                pygame.draw.line(surf, WHITE, (x, top_y + self.h), (x + 25, top_y + self.h), 1)
            txt = get_cached_text(font_sm, "<< ВНИМАНИЕ: СОЛНЕЧНЫЙ ВЫБРОС >>", WHITE)
            surf.blit(txt, (VW // 2 - 160, top_y + self.h // 2 - 8))
        elif self.active_time > 0:
            if tex_scaled is not None:
                surf.blit(tex_scaled, (0, top_y), special_flags=pygame.BLEND_ADD)
            else:
                pygame.draw.rect(surf, WHITE, (0, top_y, VW, self.h), 2)
                pygame.draw.line(surf, WHITE, (0, self.y), (VW, self.y), 1)


# =====================================================================
# === [ИНТЕРФЕЙС И МИР] ===============================================
# =====================================================================
class TouchUI:
    def __init__(self):
        self.joy_base = [170, 560]
        self.joy_pos = [170, 560]
        self.joy_r = 85
        self.knob_r = 34
        self.joy_finger = None
        self.dx = 0.0
        self.dy = 0.0

        self.btn_grav = [1100, 560, 70]
        self.grav_finger = None
        self.grav_held = False
        self.grav_released = False

        self.btn_repulse = [940, 480, 50]
        self.repulse_pressed = False

        self.btn_dash = [940, 610, 48]
        self.dash_pressed = False

        self.btn_skip = pygame.Rect(VW - 150, 20, 125, 44)
        self.skip_pressed = False

    def handle_events(self, events):
        self.dash_pressed = False
        self.repulse_pressed = False
        self.grav_released = False
        self.skip_pressed = False

        for e in events:
            if e.type == pygame.FINGERDOWN:
                vx, vy = map_touch_to_virtual(e.x, e.y)
                self._down(e.finger_id, vx, vy)
            elif e.type == pygame.FINGERMOTION:
                vx, vy = map_touch_to_virtual(e.x, e.y)
                self._move(e.finger_id, vx, vy)
            elif e.type == pygame.FINGERUP:
                vx, vy = map_touch_to_virtual(e.x, e.y)
                self._up(e.finger_id, vx, vy)

            elif e.type == pygame.MOUSEBUTTONDOWN:
                vx, vy = map_touch_to_virtual(e.pos[0] / REAL_W, e.pos[1] / REAL_H)
                self._down("mouse", vx, vy)
            elif e.type == pygame.MOUSEMOTION and pygame.mouse.get_pressed()[0]:
                vx, vy = map_touch_to_virtual(e.pos[0] / REAL_W, e.pos[1] / REAL_H)
                self._move("mouse", vx, vy)
            elif e.type == pygame.MOUSEBUTTONUP:
                vx, vy = map_touch_to_virtual(e.pos[0] / REAL_W, e.pos[1] / REAL_H)
                self._up("mouse", vx, vy)

    def _down(self, fid, x, y):
        if self.btn_skip.collidepoint(x, y):
            self.skip_pressed = True
            SOUNDS.play("blip")
            return

        if math.hypot(x - self.btn_grav[0], y - self.btn_grav[1]) <= self.btn_grav[2] * 1.35:
            self.grav_finger = fid
            self.grav_held = True
            return

        if math.hypot(x - self.btn_repulse[0], y - self.btn_repulse[1]) <= self.btn_repulse[2] * 1.35:
            self.repulse_pressed = True
            return

        if math.hypot(x - self.btn_dash[0], y - self.btn_dash[1]) <= self.btn_dash[2] * 1.35:
            self.dash_pressed = True
            return

        if x < VW * 0.45 and self.joy_finger is None:
            self.joy_finger = fid
            self.joy_base = [x, y]
            self.joy_pos = [x, y]

    def _move(self, fid, x, y):
        if fid == self.joy_finger:
            dx = x - self.joy_base[0]
            dy = y - self.joy_base[1]
            dist = math.hypot(dx, dy)
            if dist > self.joy_r:
                dx = dx / dist * self.joy_r
                dy = dy / dist * self.joy_r
            self.joy_pos = [self.joy_base[0] + dx, self.joy_base[1] + dy]
            self.dx = dx / self.joy_r
            self.dy = dy / self.joy_r

    def _up(self, fid, x, y):
        if fid == self.joy_finger:
            self.joy_finger = None
            self.joy_base = [170, 560]
            self.joy_pos = [170, 560]
            self.dx = 0.0
            self.dy = 0.0
        elif fid == self.grav_finger:
            self.grav_finger = None
            if self.grav_held:
                self.grav_held = False
                self.grav_released = True

    def draw(self, surf, mercury, in_cutscene=False):
        if in_cutscene:
            pygame.draw.rect(surf, BTN_YELLOW, self.btn_skip, 2)
            surf.blit(get_cached_text(font_md, "SKIP >>", BTN_YELLOW), (self.btn_skip.x + 20, self.btn_skip.y + 11))
            return

        pygame.draw.circle(surf, BTN_CYAN, (int(self.joy_base[0]), int(self.joy_base[1])), self.joy_r, 2)
        pygame.draw.circle(surf, BTN_CYAN, (int(self.joy_pos[0]), int(self.joy_pos[1])), self.knob_r, 2)

        g_col = BTN_YELLOW if self.grav_held else (BTN_GREEN if mercury.abilities.grav_cd <= 0 else BTN_RED)
        pygame.draw.circle(surf, g_col, (self.btn_grav[0], self.btn_grav[1]), self.btn_grav[2], 3)
        lbl = "RELEASE!" if mercury.abilities.orbit_ast else "GRAV"
        surf.blit(get_cached_text(font_md, lbl, g_col), (self.btn_grav[0] - 42, self.btn_grav[1] - 10))

        p_col = BTN_CYAN if mercury.abilities.repulse_cd <= 0 else BTN_RED
        pygame.draw.circle(surf, p_col, (self.btn_repulse[0], self.btn_repulse[1]), self.btn_repulse[2], 2)
        surf.blit(get_cached_text(font_sm, "PUSH", p_col), (self.btn_repulse[0] - 22, self.btn_repulse[1] - 8))

        d_col = BTN_GREEN if mercury.abilities.dash_cd <= 0 else BTN_RED
        pygame.draw.circle(surf, d_col, (self.btn_dash[0], self.btn_dash[1]), self.btn_dash[2], 2)
        surf.blit(get_cached_text(font_sm, "DASH", d_col), (self.btn_dash[0] - 24, self.btn_dash[1] - 8))


def generate_game_world():
    obstacles = []
    fg_asteroids = []

    for x in range(900, int(STAGE_CORONA), 260):
        obstacles.append(TrackAsteroid(x + random.randint(-40, 40), random.randint(40, VH - 40), random.randint(18, 30)))
    for x in range(int(STAGE_CORONA), int(STAGE_VENUS), 220):
        obstacles.append(TrackAsteroid(x + random.randint(-40, 40), random.randint(40, VH - 40), random.randint(20, 32)))
    for x in range(int(STAGE_VENUS), int(STAGE_BELT), 180):
        obstacles.append(TrackAsteroid(x + random.randint(-30, 30), random.randint(40, VH - 40), random.randint(20, 34)))

    for x in range(int(STAGE_BELT), int(STAGE_DEBRIS), 55):
        obstacles.append(TrackAsteroid(x + random.randint(-20, 20), random.randint(35, VH // 2), random.randint(18, 36)))
        obstacles.append(TrackAsteroid(x + random.randint(-20, 20), random.randint(VH // 2, VH - 35), random.randint(18, 36)))

    for x in range(int(STAGE_DEBRIS), int(STAGE_APPROACH), 140):
        if random.random() < 0.5:
            obstacles.append(SpaceDebris(x + random.randint(-30, 30), random.randint(40, VH - 40)))
        else:
            obstacles.append(TrackAsteroid(x + random.randint(-30, 30), random.randint(40, VH - 40), 24))

    for x in range(int(STAGE_APPROACH), int(TOTAL_GOAL_DISTANCE) - 400, 220):
        obstacles.append(TrackAsteroid(x + random.randint(-40, 40), random.randint(40, VH - 40), random.randint(18, 30)))

    for x in range(int(STAGE_BELT) - 200, int(STAGE_DEBRIS) + 200, 520):
        fg_asteroids.append(ForegroundAsteroid(x, random.choice([-20, 60, VH - 60, VH + 20])))

    return obstacles, fg_asteroids


def draw_speech(surf, x, y, name, line):
    w, h = 600, 84
    bx = max(20, min(VW - w - 20, x - w // 2))
    by = max(15, y - 130)
    pygame.draw.rect(surf, BLACK, (bx, by, w, h))
    pygame.draw.rect(surf, WHITE, (bx, by, w, h), 2)
    surf.blit(get_cached_text(font_md, name + ":", WHITE), (bx + 14, by + 10))
    surf.blit(get_cached_text(font_md, line, WHITE), (bx + 14, by + 44))


def show_sound_loading():
    if SOUNDS.check_sounds_exist():
        SOUNDS.load_sounds()
        return

    def update_bar(percent, text):
        canvas.fill(BLACK)
        t_surf = font_lg.render("ИНИЦИАЛИЗАЦИЯ ЗВУКОВОЙ СИСТЕМЫ", True, WHITE)
        canvas.blit(t_surf, (VW // 2 - t_surf.get_width() // 2, VH // 2 - 90))

        sub = font_md.render(text, True, BTN_CYAN)
        canvas.blit(sub, (VW // 2 - sub.get_width() // 2, VH // 2 - 30))

        bw, bh = 500, 22
        bx, by = (VW - bw) // 2, VH // 2 + 30
        pygame.draw.rect(canvas, (40, 40, 50), (bx, by, bw, bh), border_radius=6)
        pygame.draw.rect(canvas, BTN_GREEN, (bx, by, int(bw * percent), bh), border_radius=6)
        pygame.draw.rect(canvas, WHITE, (bx, by, bw, bh), 2, border_radius=6)

        if PORTRAIT_MODE:
            rotated = pygame.transform.rotate(canvas, -90)
            scaled = pygame.transform.scale(rotated, (REAL_W, REAL_H))
            screen.blit(scaled, (0, 0))
        else:
            scaled = pygame.transform.scale(canvas, (REAL_W, REAL_H))
            screen.blit(scaled, (0, 0))
        pygame.display.flip()

    SOUNDS.generate_missing_sounds(update_bar)
    SOUNDS.load_sounds()


def run_game():
    show_sound_loading()

    cam = LinearCamera()
    ui = TouchUI()
    mercury = Mercury()
    venus = VenusChaserAI()
    obstacles, fg_asteroids = generate_game_world()
    flares = []

    state = "CUTSCENE"
    cutscene_start_wall_time = None
    end_cutscene_timer = 0.0
    flare_spawn_timer = 5.0

    last_speech_idx = -1

    # ТОЧНЫЙ ДИНАМИЧЕСКИЙ РАСЧЁТ ДЛИТЕЛЬНОСТИ ГОЛОСОВЫХ ДОРОЖЕК
    dur_m = SOUNDS.get_duration("voice_mercury", default=4.9)
    dur_v = SOUNDS.get_duration("voice_venus", default=3.3)
    dur_s = SOUNDS.get_duration("voice_sun", default=4.4)

    cutscene_phase1 = dur_m + 0.35
    cutscene_phase2 = cutscene_phase1 + dur_v + 0.35
    cutscene_total = cutscene_phase2 + dur_s + 0.45

    base_mercury_x, base_mercury_y = 700.0, 360.0
    base_venus_x, base_venus_y = 450.0, 360.0

    bg_raw = TM.get("bg")
    bg_panorama = None
    PANORAMA_W = int(VW * 3.5)
    if bg_raw is not None:
        bg_panorama = pygame.transform.smoothscale(bg_raw, (PANORAMA_W, VH))

    running = True
    while running:
        # Плавный расчёт дельты
        dt = min(0.04, clock.tick(60) / 1000.0)

        events = pygame.event.get()
        for e in events:
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                running = False

        ui.handle_events(events)

        # ===================== НАЧАЛЬНАЯ КАТСЦЕНА С ГОЛОСАМИ =====================
        if state == "CUTSCENE":
            # СИНХРОНИЗАЦИЯ: таймер строго по реальным системным часам!
            if cutscene_start_wall_time is None:
                cutscene_start_wall_time = time.time()
            cutscene_timer = time.time() - cutscene_start_wall_time

            if ui.skip_pressed or cutscene_timer >= cutscene_total:
                SOUNDS.stop_all()
                state = "PLAY"
                mercury.emotion = "NORMAL"
                venus.emotion = "ANGRY"
                mercury.x, mercury.y = 700.0, 360.0
                venus.x, venus.y = 200.0, 360.0
                mercury.vx = 480.0
                SOUNDS.play("dash")

            m_hover = math.sin(cutscene_timer * 4.0) * 12.0
            v_hover = math.cos(cutscene_timer * 3.5) * 8.0
            talk_mouth = abs(math.sin(cutscene_timer * 13.0))

            m_anim_x = base_mercury_x
            m_anim_y = base_mercury_y + m_hover
            v_anim_x = base_venus_x
            v_anim_y = base_venus_y + v_hover
            sun_shake = 0.0

            if cutscene_timer < cutscene_phase1:
                cur_sp = 0
                mercury.emotion = "SMIRK"
                venus.emotion = "NORMAL"
                m_anim_x += math.sin(cutscene_timer * 3.0) * 15.0
                m_talk = talk_mouth if cutscene_timer < dur_m else 0.0
                v_talk = 0.0
                s_talk = 0.0
            elif cutscene_timer < cutscene_phase2:
                cur_sp = 1
                venus.emotion = "ANGRY"
                mercury.emotion = "PANIC"
                v_anim_x += random.uniform(-4.0, 4.0) + 20.0
                v_anim_y += random.uniform(-4.0, 4.0)
                m_anim_x += 25.0
                m_talk = 0.0
                v_talk = talk_mouth if (cutscene_timer - cutscene_phase1) < dur_v else 0.0
                s_talk = 0.0
            else:
                cur_sp = 2
                mercury.emotion = "PANIC"
                venus.emotion = "ANGRY"
                sun_shake = random.uniform(-2.5, 2.5)
                m_anim_x += (cutscene_timer - cutscene_phase2) * 85.0
                m_talk = 0.0
                v_talk = 0.0
                s_talk = talk_mouth if (cutscene_timer - cutscene_phase2) < dur_s else 0.0

            if cur_sp != last_speech_idx:
                last_speech_idx = cur_sp
                if cur_sp == 0:
                    SOUNDS.play("voice_mercury")
                elif cur_sp == 1:
                    SOUNDS.play("voice_venus")
                elif cur_sp == 2:
                    SOUNDS.play("voice_sun")

            if bg_panorama:
                canvas.blit(bg_panorama, (0, 0), pygame.Rect(0, 0, VW, VH))
            else:
                canvas.fill(BLACK)

            PlanetRenderer.draw_sun(canvas, 120 + int(sun_shake), 360 + int(sun_shake), 195, cutscene_timer * 3.0,
                                   talk_mouth=s_talk)

            vx_s, vy_s, _ = PlanetRenderer.draw_body(
                canvas, int(v_anim_x), int(v_anim_y), venus.r, 0.4, 0.3, "venus", venus.emotion,
                1.0, 0.0, talk_mouth=v_talk
            )
            mx_s, my_s, _ = PlanetRenderer.draw_body(
                canvas, int(m_anim_x), int(m_anim_y), mercury.r, 0.2, 0.3, "mercury", mercury.emotion,
                -1.0 if cur_sp < 2 else 1.0, 0.0, talk_mouth=m_talk
            )

            if cur_sp == 0:
                draw_speech(canvas, mx_s, my_s, "МЕРКУРИЙ", "Эй, Венера! Даже у Плутона есть луна, а ты просто злая печка!")
            elif cur_sp == 1:
                draw_speech(canvas, vx_s, vy_s, "ВЕНЕРА", "ЧТО ТЫ СКАЗАЛ, МЕЛКИЙ?! Я ТЕБЯ В ПЫЛЬ СОТРУ!")
            else:
                draw_speech(canvas, 240, 220, "СОЛНЦЕ", "А ну тихо оба! Берегись, Меркурий, сейчас будет вспышка!")

            ui.draw(canvas, mercury, in_cutscene=True)

        # ===================== ОСНОВНОЙ ГЕЙМПЛЕЙ =====================
        elif state == "PLAY":
            cam.update(dt, mercury.x, mercury.y)

            flare_spawn_timer -= dt
            if flare_spawn_timer <= 0:
                flare_spawn_timer = random.uniform(5.5, 8.5)
                flares.append(SolarFlare(random.randint(int(BOUND_TOP) + 40, int(BOUND_BOTTOM) - 40)))

            # Передаем Venus в Меркурий для авто-прицеливания при захвате
            mercury.update(dt, ui, obstacles, venus)
            venus.update(dt, mercury, obstacles)

            for f in flares[:]:
                f.update(dt, cam)
                if f.is_firing():
                    if abs(mercury.y - f.y) < (f.h // 2 + mercury.r) and mercury.invuln <= 0:
                        mercury.hp = max(0, mercury.hp - 20)
                        mercury.invuln = 0.8
                        SOUNDS.play("damage")
                if f.done:
                    flares.remove(f)

            # ТЕХНИЧЕСКАЯ ОПТИМИЗАЦИЯ:
            # Обсчитываем только те препятствия, которые рядом с экраном (+- 450px)
            view_min_x = cam.x - 450
            view_max_x = cam.x + VW + 450

            for obj in obstacles[:]:
                # Движущиеся астероиды продолжают двигаться в фоне
                if obj.is_moving:
                    obj.update(dt)

                # Если астероид далеко от экрана — пропускаем физику коллизий
                if obj.x < view_min_x or obj.x > view_max_x:
                    continue

                if not obj.is_moving:
                    obj.update(dt)

                # Венера получает урон от снарядов игрока
                if obj.owner == "player" and obj.owner_timer > 0:
                    if math.hypot(obj.x - venus.x, obj.y - venus.y) < obj.r + venus.r:
                        venus.hp = max(0, venus.hp - 15)
                        venus.stun_timer = 2.8
                        venus.vx = -380.0
                        cam.shake = 5.0
                        SOUNDS.play("hit")
                        obstacles.remove(obj)
                        continue

                # Меркурий получает урон
                if obj.owner != "player" and not obj.captured and not getattr(obj, "held_by_venus", False):
                    if math.hypot(obj.x - mercury.x, obj.y - mercury.y) < obj.r + mercury.r:
                        if mercury.invuln <= 0:
                            mercury.hp = max(0, mercury.hp - 15)
                            mercury.invuln = 0.65
                            mercury.emotion = "PANIC"
                            cam.shake = 4.0
                            if isinstance(obj, SpaceDebris):
                                SOUNDS.play("debris_hit")
                            else:
                                SOUNDS.play("damage")
                        obstacles.remove(obj)
                        continue

            for fg in fg_asteroids:
                if view_min_x - 300 <= fg.x <= view_max_x + 300:
                    fg.update(dt)

            if math.hypot(mercury.x - venus.x, mercury.y - venus.y) < mercury.r + venus.r:
                if mercury.invuln <= 0 and venus.stun_timer <= 0:
                    mercury.hp = max(0, mercury.hp - 25)
                    mercury.invuln = 0.8
                    mercury.vx += 500.0
                    cam.shake = 6.0
                    SOUNDS.play("damage")

            if mercury.invuln <= 0:
                mercury.emotion = "NORMAL"

            if mercury.x >= TOTAL_GOAL_DISTANCE:
                state = "END_CUTSCENE"
                end_cutscene_timer = 0.0
                SOUNDS.play("win")

            if mercury.hp <= 0:
                mercury = Mercury()
                venus = VenusChaserAI()
                obstacles, fg_asteroids = generate_game_world()
                flares.clear()

            # Быстрый аппаратный срез видимой части панорамы (вместо тяжелого брейка)
            progress = max(0.0, min(1.0, mercury.x / TOTAL_GOAL_DISTANCE))
            if bg_panorama:
                bg_offset_x = int(progress * (PANORAMA_W - VW))
                canvas.blit(bg_panorama, (0, 0), pygame.Rect(bg_offset_x, 0, VW, VH))
            else:
                canvas.fill(BLACK)

            for f in flares:
                f.draw(canvas)

            # Отрисовка только видимых объектов
            for obj in obstacles:
                if view_min_x <= obj.x <= view_max_x:
                    obj.draw(canvas, cam)

            venus.draw(canvas, cam, mercury)
            mercury.draw(canvas, cam, ui)

            for fg in fg_asteroids:
                if view_min_x <= fg.x <= view_max_x:
                    fg.draw(canvas, cam)

            if mercury.x > TOTAL_GOAL_DISTANCE - 1200:
                ex, ey = cam.project(TOTAL_GOAL_DISTANCE + 200, 310)
                PlanetRenderer.draw_body(canvas, ex, ey, 56, 0.2, 0.4, "earth", "HAPPY", -1.0, 0.0)
                canvas.blit(get_cached_text(font_md, "ЗЕМЛЯ", WHITE), (ex - 40, ey - 90))

                mx, my = cam.project(TOTAL_GOAL_DISTANCE + 360, 440)
                PlanetRenderer.draw_body(canvas, mx, my, 34, 0.3, 0.3, "mars", "HAPPY", -1.0, 0.0)
                canvas.blit(get_cached_text(font_md, "МАРС", WHITE), (mx - 32, my - 60))

            # ШКАЛА 6 ЭТАПОВ
            bar_w = 460
            bar_h = 14
            bx = (VW - bar_w) // 2
            by = 22
            pygame.draw.rect(canvas, WHITE, (bx, by, bar_w, bar_h), 1)

            for st_dist in [STAGE_CORONA, STAGE_VENUS, STAGE_BELT, STAGE_DEBRIS, STAGE_APPROACH]:
                sx_pos = bx + int((st_dist / TOTAL_GOAL_DISTANCE) * bar_w)
                pygame.draw.line(canvas, WHITE, (sx_pos, by - 3), (sx_pos, by + bar_h + 3), 1)

            if mercury.x < STAGE_CORONA:
                zone_name = "1/6: ОРБИТА МЕРКУРИЯ"
            elif mercury.x < STAGE_VENUS:
                zone_name = "2/6: СОЛНЕЧНАЯ КОРОНА"
            elif mercury.x < STAGE_BELT:
                zone_name = "3/6: СЕКТОР ВЕНЕРЫ"
            elif mercury.x < STAGE_DEBRIS:
                zone_name = "4/6: ПОЯС АСТЕРОИДОВ"
            elif mercury.x < STAGE_APPROACH:
                zone_name = "5/6: КЛАДБИЩЕ СПУТНИКОВ"
            else:
                zone_name = "6/6: ФИНИШ К ЗЕМЛЕ И МАРСУ"
            canvas.blit(get_cached_text(font_sm, zone_name, WHITE), (bx + 85, by + 18))

            marker_x = bx + int(progress * bar_w)
            pygame.draw.circle(canvas, WHITE, (marker_x, by + bar_h // 2), 7)

            canvas.blit(get_cached_text(font_sm, "СТАРТ", WHITE), (bx - 60, by))
            canvas.blit(get_cached_text(font_sm, "ФИНИШ", WHITE), (bx + bar_w + 14, by))

            if venus.stun_timer > 0:
                v_status = f"ОГЛУШЕНА ({venus.stun_timer:.1f}с)"
            elif venus.is_enraged:
                v_status = "В ЯРОСТИ!"
            else:
                v_status = "ПРЕСЛЕДУЕТ"

            hud_left = f"МЕРКУРИЙ: {mercury.hp}%   |   ВЕНЕРА: {venus.hp}% ({v_status})"
            canvas.blit(get_cached_text(font_md, hud_left, WHITE), (25, 20))

            ui.draw(canvas, mercury, in_cutscene=False)

        # ===================== ФИНАЛЬНАЯ КАТСЦЕНА =====================
        elif state == "END_CUTSCENE":
            end_cutscene_timer += dt

            if bg_panorama:
                canvas.blit(bg_panorama, (0, 0), pygame.Rect(PANORAMA_W - VW, 0, VW, VH))
            else:
                canvas.fill(BLACK)

            talk_mouth = abs(math.sin(end_cutscene_timer * 12.0))
            m_hover = math.sin(end_cutscene_timer * 3.5) * 8.0
            e_hover = math.cos(end_cutscene_timer * 2.8) * 6.0
            ma_hover = math.sin(end_cutscene_timer * 3.0) * 7.0

            mx = int(VW * 0.32)
            my = int(VH * 0.52 + m_hover)

            ex = int(VW * 0.65)
            ey = int(VH * 0.42 + e_hover)

            marx = int(VW * 0.85)
            mary = int(VH * 0.60 + ma_hover)

            if end_cutscene_timer < 3.6:
                m_emo, e_emo, ma_emo = "PANIC", "NORMAL", "NORMAL"
                cur_end_sp = 0
            elif end_cutscene_timer < 7.2:
                m_emo, e_emo, ma_emo = "SMIRK", "HAPPY", "NORMAL"
                cur_end_sp = 1
            elif end_cutscene_timer < 10.8:
                m_emo, e_emo, ma_emo = "HAPPY", "HAPPY", "SMIRK"
                cur_end_sp = 2
            else:
                m_emo, e_emo, ma_emo = "HAPPY", "HAPPY", "HAPPY"
                cur_end_sp = 3

            if cur_end_sp != last_speech_idx:
                SOUNDS.play("blip")
                last_speech_idx = cur_end_sp

            PlanetRenderer.draw_body(canvas, ex, ey, 58, 0.2, 0.4, "earth", e_emo, -1.0, 0.0,
                                     talk_mouth=talk_mouth if 3.6 <= end_cutscene_timer < 7.2 else 0.0)
            canvas.blit(get_cached_text(font_md, "ЗЕМЛЯ", WHITE), (ex - 40, ey - 90))

            PlanetRenderer.draw_body(canvas, marx, mary, 36, 0.3, 0.3, "mars", ma_emo, -1.0, 0.0,
                                     talk_mouth=talk_mouth if 7.2 <= end_cutscene_timer < 10.8 else 0.0)
            canvas.blit(get_cached_text(font_md, "МАРС", WHITE), (marx - 32, mary - 60))

            PlanetRenderer.draw_body(canvas, mx, my, mercury.r, 0.2, 0.3, "mercury", m_emo, 1.0, 0.0,
                                     talk_mouth=talk_mouth if end_cutscene_timer < 3.6 else 0.0)
            canvas.blit(get_cached_text(font_md, "МЕРКУРИЙ", WHITE), (mx - 48, my - 60))

            if end_cutscene_timer < 3.6:
                draw_speech(canvas, mx, my, "МЕРКУРИЙ", "Фух... Ребята, спасите! Венера совсем взбесилась и кидалась камнями!")
            elif end_cutscene_timer < 7.2:
                draw_speech(canvas, ex, ey, "ЗЕМЛЯ", "Меркурий, ты добрался! Не бойся, рядом с нами она тебя не тронет!")
            elif end_cutscene_timer < 10.8:
                draw_speech(canvas, marx, mary, "МАРС", "Ха! Пусть только сунется! Мы с Фобосом и Деймосом её мигом остудим!")
            else:
                banner = get_cached_text(font_lg, "ПОБЕДА! ТЫ СПАССЯ ОТ ВЕНЕРЫ!", BTN_GREEN)
                canvas.blit(banner, (VW // 2 - banner.get_width() // 2, VH // 2 - 120))
                sub = get_cached_text(font_md, "Нажми на экран, чтобы сыграть снова", WHITE)
                canvas.blit(sub, (VW // 2 - sub.get_width() // 2, VH // 2 - 60))

            ui.draw(canvas, mercury, in_cutscene=True)

            if (ui.skip_pressed or end_cutscene_timer >= 10.8) and (ui.dash_pressed or ui.grav_held or ui.repulse_pressed or ui.skip_pressed):
                mercury = Mercury()
                venus = VenusChaserAI()
                obstacles, fg_asteroids = generate_game_world()
                flares.clear()
                state = "PLAY"

        # Вывод на дисплей телефона
        if PORTRAIT_MODE:
            rotated = pygame.transform.rotate(canvas, -90)
            scaled = pygame.transform.scale(rotated, (REAL_W, REAL_H))
            screen.blit(scaled, (0, 0))
        else:
            scaled = pygame.transform.scale(canvas, (REAL_W, REAL_H))
            screen.blit(scaled, (0, 0))

        pygame.display.flip()


if __name__ == "__main__":
    try:
        run_game()
    except Exception:
        err_lines = traceback.format_exc().splitlines()
        while True:
            for ev in pygame.event.get():
                if ev.type in (pygame.QUIT, pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                    pygame.quit()
                    sys.exit()
            screen.fill((0, 0, 0))
            y_off = 40
            for line in err_lines[-18:]:
                txt = font_sm.render(line, True, (255, 255, 255))
                screen.blit(txt, (20, y_off))
                y_off += 28
            pygame.display.flip()
            clock.tick(15)
